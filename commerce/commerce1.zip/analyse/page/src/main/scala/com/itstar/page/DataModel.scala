package com.itstar.page

case class PageSplitConvertRate(taskid: String, convertRate: String)